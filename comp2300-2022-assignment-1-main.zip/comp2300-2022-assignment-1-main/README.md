# COMP2300 Assignment 1 Template 

This is the template repository for COMP2300 assignment 1.

You should look at the assignment instructions online: https://comp.anu.edu.au/courses/comp2300/assessments/light-show
