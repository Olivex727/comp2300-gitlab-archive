---
# for information & examples on how to fill this out correctly, see
# https://comp.anu.edu.au/courses/comp2300/resources/faq/#statement-of-originality
declaration: >-
  I declare that everything I have submitted in this assignment is entirely my
  own work, with the following exceptions:

# sign *your* name and uid here
name: Olivia Walters
uid: u7280249
---