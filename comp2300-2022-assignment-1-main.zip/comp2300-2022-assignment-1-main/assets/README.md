## Assets Directory

This directory is for storing "assets" (e.g., images or other files) related to your assignment that you might refer to in your `design-document.md`. If you don't want to put any images in your design document, you can ignore this directory.

For instructions about how to use images in your design document, see the course website: https://comp.anu.edu.au/courses/comp2300/resources/design-document/

If you do upload any assets here, please keep them **small**, e.g., less than 500kB.
